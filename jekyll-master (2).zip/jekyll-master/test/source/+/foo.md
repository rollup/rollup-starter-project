---
layout: default
title : Page inside +
permalink: /+/plus+in+url.html
---
Line 1
{{ page.title }}
