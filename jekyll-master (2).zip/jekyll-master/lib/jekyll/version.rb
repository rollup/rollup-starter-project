module Jekyll
  VERSION = "3.3.1".freeze
end
